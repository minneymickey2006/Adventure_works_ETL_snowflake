{% macro salesperson_commission(count_of_product,commission) %}
    case
            when {{ count_of_product }} = 1000 then {{ commission }} * 1.5
            when {{ count_of_product }} = 500 then {{ commission }} * 0.5
            else {{ commission }}
        end
{% endmacro %}
