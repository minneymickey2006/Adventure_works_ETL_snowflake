{{ dbt_date.get_date_dimension("2011-01-01", run_started_at.strftime("%Y-%m-%d")) }}
