--with join_dim_fact_customer as(
    --select * from {{ref('fct_sales')}}
    --inner join {{ref('dim_customer')}}
    --on {{ref('fct_sales')}}.customer_key = {{ref('dim_customer')}}.customer_key
--)

--select * from join_dim_fact_customer